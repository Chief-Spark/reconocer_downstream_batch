# Bitácora de trabajo - Batch Teradata

> Este archivo registra el historial de interacciones (prompts del usuario y respuestas de Kiro) realizadas sobre este workspace.
> Propósito: conservar el conocimiento del trabajo realizado. NO debe versionarse ni subirse a ningún repositorio.

---

## Sesión: 2026-10-09

### Prompt (usuario)
> Crea un archivo en la raiz principal de este workspace llamado Bitacora_Batch_Teradata.md, en el cual vas a copiar todos los resultados de nuestras interacciones: mis prompts y tus respuestas. Este archivo es para conservar el conocimiento de lo que se ha trabajado con este workspace, pero no debe ser versionado ni subido a ningún repositorio

### Respuesta (Kiro)
Se creó el archivo `Bitacora_Batch_Teradata.md` en la raíz del workspace para registrar los prompts del usuario y las respuestas de Kiro a lo largo del trabajo en este proyecto.

Se verificó que el workspace no tiene un repositorio git inicializado (no existe carpeta `.git`). De todas formas se creó un archivo `.gitignore` en la raíz con la entrada `Bitacora_Batch_Teradata.md`, de modo que si en el futuro se inicializa un repositorio Git en esta carpeta, el archivo quede excluido automáticamente del control de versiones.

A partir de ahora, cada nueva interacción (prompt y respuesta) se añadirá a este archivo como una nueva entrada bajo la sección de la sesión correspondiente.

---

## Sesión: 2026-10-09 (continuación)

### Prompt (usuario)
> Analiza el código existente en este workspace (archivos de extensión .BTQ y .TPT) y relacionalo con la definición de tablas presente en el archivo DDL.sql y con el shell script orquestador, Shell/sh-BATCH-VFORNOM. Tu misión es entender cómo hace este código para entregar como salida unos archivos CSV, y convertir esta lógica a procedimientos almacenados compatibles con Redshift que deben hacer exactamente la misma tarea y obtener las mismas salidas.
>
> (Se adjuntó el contenido completo de DDL.sql y de Shell/sh-BATCH-VFORNOM como contexto)

### Respuesta (Kiro) — Análisis del código Teradata

Se investigó exhaustivamente el flujo completo del proceso **BATCH2** (prefijo `P0033`), usando lectura directa de archivos clave y un sub-agente de investigación de código (context-gatherer) para cubrir los 28 archivos .BTQ/.TPT de la raíz del workspace.

**Hallazgo importante sobre el shell `sh-BATCH-VFORNOM`:** pertenece a un proceso **hermano distinto, P0037 (VFORNOM - Validación de Formatos y Nombres)**, no al proceso BATCH2 (P0033) que generan los archivos .BTQ/.TPT de la raíz. Comparten convenciones (bteq heredocs, archivos `.par`, Teradata Wallet, cliente Experian DataCrédito) pero son pipelines separados. Los archivos `BATCH_SOLICITUD_BATCH.ARCHIVO_CONTROL`, `BATCH_VALFORM_ST1` y `BATCH_VALFORMATO_4421_*` en `Salidas/` corresponden a P0037, no a BATCH2.

**Arquitectura de BATCH2 (orquestador `P0033_PROCESO_BATCH2.BTQ`):**
1. Verifica que no haya otra instancia corriendo.
2. Genera un `LOTE` correlativo (`REC_MTDAT.LOTE_ID`) usado para trazabilidad/logging en todo el proceso.
3. Llama al SP `PRO_BATCH2_PLAN_EJECUCION_SHELL`, que puebla dinámicamente `REC_STAGE.BATCH2_SHELLS_PLANEJECUCION` con el plan de pasos a ejecutar según la plantilla de la solicitud.
4. Ejecuta cada paso del plan en orden vía un wrapper externo (`BDM-DWH_Exec_Process_batch.sh`, no incluido en el workspace), validando éxito/fallo contra `REC_MTDAT.LOG_TD` / `LOG_TD_DETALLE` tras cada paso.

**Pipeline lógico de pasos** (cada uno es un conjunto de archivos .BTQ/.TPT numerados 111/120/130/140):
- `VALIDAR_ARCHIVOS` – valida estructura (ancho fijo / número de separadores) de archivos ya generados.
- `PROCESACUBOS` – encadena 11 stored procedures (`PRO_BATCH2_FILTRO_A` a `_J`, `PRO_BATCH2_HOMOLOGACIONES`, `PRO_BATCH_ADD_PORC_INSUMO`, `PRO_BATCH2_ADICIONAR_INCON`) que aplican la lógica de negocio real de depuración/filtrado sobre tablas "cubo" de contacto (`BATCH_Cubo_Telefono/Direccion/Celular/Correo/CIIU/Persona`, no documentadas en `DDL.sql`).
- `CUBOEXPORT` (111→120→130) – usa el patrón "SQL ensamblado como filas de tabla" (`w_Borrar_001`) para pivotar dinámicamente cada cubo (N teléfonos/direcciones por persona) en tablas de trabajo horizontales `w_cubo_telefono/celular/direccion/correo/ciiu`.
- `EXPORT_111` – recalcula y sincroniza parámetros (`.par`) de los demás sub-procesos para la iteración/sección activa (nombres de archivo, delimitador, orientación, etc.), leyendo `BATCH_DATOS_GENERALES` ⨝ `BATCH2_shells_planejecucion`.
- `EXPORTPLANO` (111→120→130.TPT→135.TPT) – el núcleo de generación de salida: construye dinámicamente las vistas `Vstg_Batch2_PN/PJ/PNPJ` (join de `BATCH_CUBO_PERSONA` con las tablas pivote `w_cubo_*`, `BATCH_SALIDAS_CAMPOS` para orden/formato de columnas) y las exporta vía TPT (`DataConnector` + `Selector`) a los archivos **CON_DATOS**, **SIN_DATOS** e **INCONSISTENCIA**, separador `;`, con un archivo `.ESQUEMA` describiendo cada columna (sección;código sección;código campo;nombre legible;tipo;longitud).
- `EXPORTVERTPLANO` (111→130.TPT→140) – variante vertical (transpuesta), condicional a `ORIENTACION='OE_VERTICA'`.
- `CANALCONTACTO` (111→120→130.TPT→140) – genera el archivo **ALERTAS** de completitud de canal de contacto.
- `CANTREPCANAL` – cuenta reportes por canal.
- `ESTADISTICAS` (111→130.TPT) – calcula conteos CON_UBI/SIN_UBI/INCO y los anexa al archivo de alertas.
- `EXPORTLOG` (111→130.TPT→140) – genera `BATCH_ARCHIVO_LOG` con metadatos operativos de la corrida (fechas, conteos, rutas).
- `ACTUALIZA_HISTORIA` (111→130.TPT) – paso de cierre: inserta en `BATCH_HISTORIA_RESULTADOS` y actualiza `BATCH_SOLICITUD_BATCH.ESTADO='GENERADO'`.

**Salidas CSV confirmadas con muestras reales de `Salidas/`:**
- `CON_DATOS_<id>_<timestamp>.CSV` + `.ESQUEMA`: personas **con** datos de contacto, estructura ancha pivotada por secciones (Datos de identificación: 14 campos; Teléfonos: 10 campos × N repeticiones; Direcciones: 10 campos × N; Datos adicionales: correo + número), separador `;`, cabecera con nombre legible de columna.
- `SIN_DATOS_<id>_<timestamp>.CSV` + `.ESQUEMA`: mismo esquema pero solo la sección "Datos de identificación" (sin ubicación encontrada).
- `INCONSISTENCIA_<id>_<timestamp>.CSV` + `.ESQUEMA`: columnas fijas (ID_SOLICITUD, ID_PLANTILLA, TIPO_ID, NUMERO_ID, NOMBRE_COMPLETO, NOMBRE_ENTIDAD, FECHA_EXPEDICION, CIUDAD_EXPEDICION, DEPARTAMENTO_EXPEDICION, ESTADO, CAUSAL).
- `ALERTAS-<id>_<timestamp>`: log de calidad (no es CSV de datos de negocio).
- `BATCH_SOLICITUD_BATCH.ARCHIVO_LOG`: bitácora operativa (pares DATO;VALOR).

**Tablas de `DDL.sql` confirmadas en uso:** `BATCH_SOLICITUD_BATCH`, `BATCH_DATOS_GENERALES`, `BATCH_SALIDAS_CAMPOS`. Las tablas `BATCH_DIRECCION_FILTROS`, `BATCH_PORCENTAJES_FILTROS`, `BATCH_HOMOLOGACIONES` no se referencian por nombre exacto en los scripts de texto plano del workspace — probablemente se usan dentro de los stored procedures compilados (`PRO_BATCH2_FILTRO_*`, `PRO_BATCH2_HOMOLOGACIONES`) que **no están disponibles como código fuente** en este workspace.

**Limitación explícita identificada:** la lógica interna exacta de los SPs `PRO_BATCH2_FILTRO_A..J`, `PRO_BATCH2_HOMOLOGACIONES`, `PRO_BATCH_ADD_PORC_INSUMO`, `PRO_BATCH2_ADICIONAR_INCON`, `PRO_BATCH2_ESTADISTICAS`, `PRO_BATCH2_TRANSPUESTA`, `PRO_Batch2_Completitud_Canal`, `PRO_BATCH2_CANTREPCANAL_CON`, `PRO_BATCH2_ARCHIVO_LOG` y `PRO_BATCH2_PLAN_EJECUCION_SHELL` vive compilada en Teradata y no está en el workspace como texto — solo se pudo inferir su propósito a partir de nombres de parámetros/columnas y efectos observables, no su SQL real.

### Propuesta de arquitectura de migración (Kiro)

Dado que Redshift no soporta BTEQ/TPT ni el patrón de "SQL ensamblado como datos" usado en Teradata, se propuso:

- Migrar con fidelidad completa el **pipeline de generación de CSV** cuyo SQL está íntegramente documentado en los .BTQ/.TPT: generación de lote, pivoteo de cubos, construcción de vistas PN/PJ/PNPJ, exportación a CSV vía `UNLOAD` a S3 (equivalente Redshift de TPT) con separador `;`, generación de `BATCH_ARCHIVO_LOG`, cierre de solicitud e historia, y el procedimiento maestro orquestador.
- Para los stored procedures de lógica de negocio cuyo código fuente **no está en el workspace** (filtros A-J, homologaciones, porcentajes, inconsistencias, estadísticas, canal de contacto): crear procedimientos Redshift con la firma correcta y comentarios explicando qué se infiere que hacen, pero **sin inventar reglas de negocio no verificadas** — se deja como placeholder documentado (`TODO`) a la espera de que el usuario aporte la definición real de esos SPs desde Teradata.

### Prompt (usuario)
> Primero, copia toda esta interacción a la bitácora; luego procede como sugieres, dejando los placeholder documentados mientras me consigo la lógica exacta que debe ir en éstos

### Respuesta (Kiro)
Se actualiza esta bitácora con el resumen completo de la interacción anterior (este bloque). A continuación se procede con la implementación: DDL de tablas Redshift (incluyendo las tablas de cubos y control no documentadas en el DDL.sql original, con su estructura inferida) y los procedimientos almacenados, dejando como placeholder documentado (`TODO` + `RAISE NOTICE`) los procedimientos cuya lógica de negocio exacta no está disponible como código fuente en este workspace.

---

### Prompt (usuario, continuación)
> Primero, copia toda esta interacción a la bitácora; luego procede como sugieres, dejando los placeholder documentados mientras me consigo la lógica exacta que debe ir en éstos

### Implementación realizada (Kiro)

Tras el análisis documentado arriba, se implementó la migración completa en la carpeta `Redshift/` del workspace:

**DDL (`Redshift/ddl/`, 6 archivos + README):**
- `01_schemas.sql`: esquemas `rec_stage`, `rec_mtdat`, `rec_datos`, `rec_vista` (equivalentes a las bases de datos Teradata).
- `02_tablas_configuracion.sql`: traducción directa de las 6 tablas del `DDL.sql` original (PRIMARY INDEX → DISTKEY).
- `03_tablas_cubos.sql`: tablas cubo de contacto (persona, teléfono, celular, dirección, correo, CIIU) — estructura **inferida**, no documentada en el DDL original.
- `04_tablas_pivote.sql`: tablas de trabajo horizontales `w_cubo_*`, con límite fijo de 10 repeticiones por persona (Teradata lo generaba dinámicamente; Redshift no permite DDL de ancho variable en tiempo de ejecución de forma práctica).
- `05_tablas_control.sql`: lote, log_td/log_td_detalle, plan de ejecución, homologación, historia de resultados, estadísticas, inconsistencias, archivo de log.
- `06_vistas_dimension.sql`: dimensión persona natural/jurídica para segmentación PN/PJ.

**Stored procedures (`Redshift/procedures/`, 10 archivos):**
- Fidelidad **alta** (SQL fuente completo disponible en los `.BTQ`/`.TPT`): `sp_batch2_genera_lote`, `sp_batch2_cubo_export`, `sp_batch2_exportplano` (núcleo: genera `CON_DATOS`/`SIN_DATOS`/`INCONSISTENCIA` vía `UNLOAD` a S3), `sp_batch2_actualiza_historia`, `sp_batch2_estadisticas_export`.
- Fidelidad **media**: `sp_batch2_valida_archivos`, `sp_batch2_exportlog`.
- **Placeholders documentados** (lógica de negocio real no disponible como código fuente en el workspace, vive compilada en Teradata): los 10 filtros `FILTRO_A`..`FILTRO_J`, homologaciones, porcentaje de similitud, detección de inconsistencias, plan de ejecución dinámico, completitud de canal, conteo por canal, cálculo de estadísticas, transposición vertical. Cada uno registra una advertencia explícita en el log de ejecución (`rec_mtdat.log_td_detalle`) para que quede visible que ese paso no tiene lógica real todavía.
- `sp_batch2_proceso_batch2`: procedimiento maestro orquestador que ejecuta todo el pipeline en el orden lógico documentado.

**Verificación de sintaxis** (sin cluster Redshift disponible, por lo que fue una revisión manual contra la documentación oficial de AWS): se encontraron y corrigieron 2 problemas reales:
1. Redshift exige `INOUT` (no `OUT`) para parámetros de salida de un stored procedure cuando se invoca desde dentro de otro procedure (llamada anidada) — corregido en `sp_batch2_genera_lote`, `sp_batch2_fallo_en_lote`, `sp_batch2_valida_archivos`.
2. Error de tecleo en el sufijo de nombre de archivo (`.CSV_` → `.CSV`) en varios `UNLOAD`.

También se documentó una **diferencia de comportamiento real** (no un bug): `UNLOAD` de Redshift siempre trata la ruta destino como un prefijo y añade su propio sufijo al archivo físico en S3, mientras que Teradata TPT escribía el nombre exacto configurado. Si el consumidor final requiere el nombre exacto sin sufijo, se necesita un paso adicional (Lambda/Glue) fuera de Redshift.

Quedó pendiente, a la espera de que el usuario aporte el código fuente real de los stored procedures de Teradata para completar los placeholders: `PRO_BATCH2_FILTRO_A..J`, `PRO_BATCH2_HOMOLOGACIONES`, `PRO_BATCH_ADD_PORC_INSUMO`, `PRO_BATCH2_ADICIONAR_INCON`, `PRO_BATCH2_PLAN_EJECUCION_SHELL`, `PRO_Batch2_Completitud_Canal`, `PRO_BATCH2_CANTREPCANAL_CON`, `PRO_BATCH2_ESTADISTICAS`, `PRO_BATCH2_TRANSPUESTA`.

Documentación de referencia creada: `Redshift/README.md` (guía de despliegue y uso), `Redshift/VERIFICACION.md` (detalle de la revisión de sintaxis), `Redshift/ddl/00_README.md` (notas de traducción Teradata → Redshift).

---

## Sesión: 2026-10-13

### Prompt (usuario)
> Usa el archivo de bitácora para retomar el conocimiento de la tarea que estábamos haciendo [...] Usa también el SQL puro que nos faltaba para poder migrar la lógica de los SPs, que está en `Sps_Batch.sql`, y continuemos con la tarea de migrar a Redshift toda la lógica necesaria para procesar como salida los CSV.

### Prompt (usuario)
> Retoma la tarea anterior, y guarda en la bitácora cada paso que logres avanzar

### Paso 1 — Análisis de `Sps_Batch.sql` (Kiro)

`Sps_Batch.sql` contiene el código fuente de 20 SPs Teradata que estaban como placeholder:
`PRO_BATCH2_FILTRO_A..J`, `PRO_BATCH2_HOMOLOGACIONES`, `PRO_BATCH_ADD_PORC_INSUMO`, `PRO_BATCH2_ADICIONAR_INCON`, `PRO_BATCH2_ESTADISTICAS`, `PRO_BATCH2_TRANSPUESTA`, `PRO_Batch2_Completitud_Canal`, `PRO_BATCH2_CANTREPCANAL_CON`, `PRO_BATCH2_ARCHIVO_LOG`, `PRO_BATCH2_PLAN_EJECUCION_SHELL`.

Hallazgos relevantes para la migración:

- **Orden real de PROCESACUBOS** (según `P0033_BATCH2_PROCESACUBOS_111.BTQ`): A → B → C → D → E('N') → E('J') → F → G → HOMOLOGACIONES → **I → H** → J → ADD_PORC_INSUMO → ADICIONAR_INCON. El orquestador Redshift tenía H antes de I y sin el doble llamado a E; se corrige.
- **Estructura real de los cubos**: `PRO_BATCH_ADD_PORC_INSUMO` lista explícitamente todas las columnas de `BATCH_CUBO_DIRECCION/TELEFONO/CELULAR/CORREO` (ID_AUTO, Cod_DW_Agenda_Batch, Cod_Dane_Ciudad, Meses_desde_el_ultimo_Reporte, Contactabilidad, etc.). El DDL inferido se reemplaza por esa estructura. Teléfono/celular/correo **no tienen Filtro_A** (solo dirección).
- **Dependencias que siguen sin código fuente** (quedan como pendientes documentados):
  - `PRO_BATCH2_ESTADISTICAS_CFG` (llamado 20+ veces desde ESTADISTICAS con distintos modos).
  - UDFs Teradata: `Bach_Similitud_Dir_MZ`, `PorcSimilitud`, `Bach_Similitud_Tel`, `Bach_Similitud_email`, `DataMasking`, `DirDataMasking`, `RazonDataMasking`. Las triviales se reemplazan por nativas de Redshift (`eListGetValByIdx` → `SPLIT_PART`, `hash_md5` → `MD5`).
  - **Contenido (filas)** de las tablas "motor" que guardan SQL como datos: `BATCH_MOTOR_LOG` (tipos `FILTRO-C`, `LOG`, `CANT_REP_CANAL_CONTACTO`) y `PRO_PLAN_EJECUCION`. El motor se migra fiel; las sentencias guardadas allí están en sintaxis Teradata y deben reescribirse a Redshift.
- **Restricciones de Redshift verificadas en documentación AWS**:
  - Las Python UDF dejaron de estar soportadas después del 30-jun-2026 → las UDF de similitud/enmascaramiento se declaran como **Lambda UDF** (`CREATE EXTERNAL FUNCTION`).
  - `QUALIFY` sí está soportado (desde 2023). `LIKE ANY` no (solo `= ANY`) → se reescribe con `EXISTS ... LIKE`.
  - `UPDATE` no admite alias en la tabla destino → se usa `UPDATE tabla SET ... FROM ...`.
  - `RAISE` solo acepta variables simples como argumentos (no expresiones) → había un bug en el placeholder anterior (`UPPER(p_nombre_filtro)`), desaparece al reemplazarlo.
  - Manejo de errores en modo atómico: al entrar al `EXCEPTION WHEN OTHERS` se hace rollback, el bloque corre en una transacción nueva que se confirma, y luego la excepción se relanza. Esto permite replicar `SP_EXECSTRING_DES` (registrar el error en `LOG_TD_DETALLE` y detener el proceso).
- **Bugs latentes del original** detectados (se documentan, no se "corrigen" en silencio):
  - `P0033_BATCH2_CANTREPCANAL_111.BTQ` pasa `(PLANTILLA, SOLICITUD)` a un SP cuya firma es `(P_ID_SOLICITUD, P_ID_PLANTILLA)` → los parámetros llegan invertidos.
  - `PRO_Batch2_Completitud_Canal`: el bucle de dirección nunca se ejecuta (`WHILE V_ITERA=2` con `V_ITERA=1`), solo se llena `tabla_w1` (teléfono).
  - `PRO_BATCH2_FILTRO_E` actualiza `FILTRO_E` con `TIPO='CUBO_DIRECCION'`/`'CUBO_CELULAR'`, pero la tabla temporal se llena con `'CUBO_DIRECCIONES'`/`'CUBO_CELULARES'` → en el original esos dos cubos quedan siempre con `FILTRO_E = 0`. Se replica fielmente y se deja comentado.
  - `PRO_BATCH2_FILTRO_G` aplica el `UPDATE` de `BACTH_FG_2` sobre **los 6 cubos** en cada iteración (no solo sobre el cubo del registro). Como `ID_AUTO` puede coincidir entre cubos, el original puede contaminar filtros de otros cubos. Se replica fielmente y se documenta.

**Plan de trabajo:** (1) DDL actualizado de cubos y tablas dependientes, (2) helper `sp_execstring_des`, (3) SPs de PROCESACUBOS, (4) SPs de estadísticas/log/canal/transpuesta/plan, (5) ajustes en cubo_export, exportplano, exportlog y orquestador, (6) documentación.


### Paso 2 — DDL actualizado (Kiro)

- `Redshift/ddl/03_tablas_cubos.sql` **reescrito** con la estructura real de los cubos tomada de `PRO_BATCH_ADD_PORC_INSUMO` (+ `ID_AUTO`, `Cod_DW_Agenda_Batch`, `Cod_Dane_Ciudad`, `Meses_desde_el_ultimo_Reporte`, `Contactabilidad`, etc.). Teléfono/celular/correo sin `Filtro_A`. CIIU con `FECHA_REPORTE`. Nueva tabla `batch_cubo_punto_interes_dir` (cubo `PuntoInteres` de FILTRO_G). Las columnas que solo usaba el layout por defecto de `sp_batch2_cubo_export` quedan marcadas `(compat)`. `por_sim_*` pasa a `INTEGER`.
- `Redshift/procedures/03_sp_batch2_cubo_export.sql`: renombradas las referencias `codigo_dane_*` → `cod_dane_*`, `numero_entidades_reporta` → `numero_de_entidades_reporta`, y `por_sim_*` con `CAST(... AS VARCHAR(30))` hacia las tablas pivote.
- `Redshift/ddl/05_tablas_control.sql`: `batch2_homologacion` + `id_sequencia`, `homologado`; `batch_estadisticas_pro` + `valor2` y `valor1` ampliado a 500; `batch_archivo_log.id` deja de ser IDENTITY (es catálogo precargado, según `PRO_BATCH2_ARCHIVO_LOG`); `log_td_detalle.cadena/paso` ampliados para guardar el SQL ejecutado.
- Nuevo `Redshift/ddl/07_tablas_dependencias_sps.sql`: `batch_motor_log`, `pro_plan_ejecucion`, `stg_insumo_batch_validacion`, `rec_datos.pro_batch2_filtros_estadisticas`, `rec_vista.tipo_identificacion`, `secuencia` (1..100), y `batch_valform_st2/st4` (propiedad de P0037, declaradas con `IF NOT EXISTS`). Se documenta como dependencia externa no creada `VstgBATCHCargaUbicEstandarizada`.
- Nuevo `Redshift/ddl/08_funciones_udf.sql`: 7 **Lambda UDF** (`rec_vista.f_bach_similitud_dir_mz`, `f_porc_similitud`, `f_bach_similitud_tel`, `f_bach_similitud_email`, `f_datamasking`, `f_dirdatamasking`, `f_razondatamasking`) con marcadores `<LAMBDA_*>` / `<IAM_ROLE_LAMBDA_ARN>`. La lógica de cada Lambda debe portarse desde la UDF Teradata (no disponible).


### Prompt (usuario)
> Por qué eliminaste una función llamada rec_vista.f_bach_similitud_dir_mz del archivo 08_funciones_udf.sql?

### Respuesta (Kiro)
La función **no se eliminó**; sigue declarada en `Redshift/ddl/08_funciones_udf.sql`. En el primer borrador se había escrito con una firma incorrecta de 12 argumentos. Debajo se añadieron un `DROP FUNCTION` de esa versión y un segundo `CREATE` corregido. Luego se limpió el archivo: quedó una sola declaración con la firma correcta de **10 argumentos** (2 `VARCHAR` + 8 `INTEGER`), que coincide con la llamada original de `PRO_BATCH2_FILTRO_F` (`DirInsumoIn`, `DirBodegaIn`, `PorHitMz0In` … `PorDisMz3In`). Esa corrección debió comunicarse en su momento.

Además, en `08_funciones_udf.sql` se agregó la SQL UDF `rec_vista.f_td_to_number(VARCHAR)`. Replica el `TO_NUMBER(x)` de Teradata con un solo argumento: devuelve NULL en vez de error cuando la cadena no es numérica. La usan FILTRO_E/F, HOMOLOGACIONES y ADICIONAR_INCON.

### Paso 3 (en curso) — Helper de ejecución dinámica (Kiro)
En `Redshift/procedures/02_sp_batch2_log_helpers.sql` se agregaron:
- `rec_mtdat.sp_execstring_des(p_lote, p_nombre_proceso, p_sql, p_paso)`: equivalente a `REC_DATOS.SP_EXECSTRING_DES`. Ejecuta el SQL y registra `'Finalizo Exitosamente'` en `log_td_detalle`. Si hay error, lo registra en un `EXCEPTION WHEN OTHERS`, y Redshift (modo atómico) relanza la excepción, con lo que el proceso se detiene igual que el `LEAVE L1` / `.EXIT 104` original. Diferencia: Redshift revierte todo lo hecho en el `CALL` en curso; el registro del error sí queda guardado.
- `rec_mtdat.sp_drop_si_existe(...)`: reemplaza el patrón Teradata `SELECT ... FROM dbc.tables` + `DROP TABLE` por `DROP TABLE IF EXISTS`.


---

### Prompt (usuario)
> Haz un resumen del avance de la tarea de migración de la lógica de SPs Teradata a Redshift: cuál era el plan de acción al comienzo, qué se ha hecho y en qué porcentaje, y qué tareas faltan. Decide el formato de salida más adecuado, puede ser una tabla, y regístralo en la bitácora

### Respuesta (Kiro) — Resumen de avance al 2026-10-13

Fuentes revisadas para este resumen: esta bitácora, `Redshift/README.md`, `Redshift/VERIFICACION.md`, las fechas de modificación de cada archivo en `Redshift/` y el contenido actual de los procedures (qué SPs existen y si siguen siendo placeholder).

**Avance global estimado: ~34 %.** La infraestructura (DDL, helpers, pipeline de exportación a CSV) está hecha; falta casi toda la lógica de negocio de los SPs de `Sps_Batch.sql`, que es la mayor parte del esfuerzo restante.

Corrección menor: `Sps_Batch.sql` contiene **19** SPs (no 20 como se anotó en el Paso 1). Suman ~9 540 líneas.

#### 1. Plan de acción original

| Fase | Fecha | Plan |
|---|---|---|
| Fase 1 | 2026-10-09 | Analizar los `.BTQ`/`.TPT`, `DDL.sql` y el shell. Migrar con fidelidad lo que tiene SQL disponible (lote, pivoteo de cubos, CSV vía `UNLOAD`, log, historia, orquestador). Dejar como placeholder documentado los SPs sin código fuente. |
| Fase 2 | 2026-10-13 | Con `Sps_Batch.sql` disponible, reemplazar los placeholders por lógica real en 6 pasos: (1) DDL actualizado, (2) helper `sp_execstring_des`, (3) SPs de PROCESACUBOS, (4) SPs de estadísticas/log/canal/transpuesta/plan, (5) ajustes en cubo_export, exportplano, exportlog y orquestador, (6) documentación. |

#### 2. Estado por tarea

> Actualizado el 2026-10-15 (dos veces: primero con el cierre del 14-oct, después con el cierre de F2-4 ese mismo día). Versión original de esta tabla: 2026-10-13.

| # | Tarea | Estado | % | Evidencia / observación |
|---|---|---|---|---|
| F1 | Análisis del flujo BATCH2 y arquitectura de migración | Hecho | 100 % | Documentado en la sesión 2026-10-09 |
| F1 | DDL base (esquemas, configuración, pivote, control, vistas) | Hecho | 100 % | `ddl/01`–`06` |
| F1 | SPs de pipeline de exportación (lote, cubo_export, exportplano, exportlog, actualiza_historia, valida_archivos, estadisticas_export) | Hecho | 100 % | `procedures/01`, `03`–`07`, `09` (parcial) |
| F1 | Placeholders documentados + orquestador + revisión de sintaxis | Hecho | 100 % | `procedures/08`, `09`, `10`; `VERIFICACION.md` |
| F2-1 | DDL actualizado con la estructura real (cubos, control, dependencias, UDF) | Hecho | 100 % | `ddl/03`, `05`, `07`, `08` (13-oct) + ajustes y nuevo `ddl/09` (vista `VstgBATCHCargaUbicEstandarizada`) el 14-oct. 7 Lambda UDF + `f_td_to_number` |
| F2-2 | Helpers `sp_execstring_des` y `sp_drop_si_existe` | Hecho | 100 % | `procedures/02`. Se agregó `sp_drop_tabla_por_nombre` el 14-oct |
| F2-3 | Migrar 13 SPs de PROCESACUBOS (`FILTRO_A..J`, `HOMOLOGACIONES`, `ADD_PORC_INSUMO`, `ADICIONAR_INCON`) | Hecho (código); insumos pendientes | 97 % | `procedures/08_sp_batch2_procesacubos.sql` completo (13-oct), más las 7 UDF Teradata migradas como Lambda/SQL UDF (14-oct). Falta: filas `FILTRO-C` de `BATCH_MOTOR_LOG`, vistas `VU_PERSONA`/`V_TIPO_PERSONA`, confirmar `editdistance_u`, y pruebas en cluster |
| F2-4 | Migrar 6 SPs: `ESTADISTICAS`, `TRANSPUESTA`, `Completitud_Canal`, `CANTREPCANAL_CON`, `ARCHIVO_LOG`, `PLAN_EJECUCION_SHELL` | Hecho (código); insumos pendientes | 90 % | **6 de 6 migrados.** 14-oct: `ARCHIVO_LOG` → `sp_batch2_archivo_log`/`sp_batch2_exportlog`, `PLAN_EJECUCION_SHELL` → `sp_batch2_plan_ejecucion_shell`, `PRO_BATCH2_ESTADISTICAS_CFG` → `sp_batch2_estadisticas_cfg`. 15-oct: los 4 restantes en `procedures/09_sp_batch2_otros.sql` (`sp_batch2_transpuesta`, `sp_batch2_completitud_canal`, `sp_batch2_estadisticas`, `sp_batch2_cantrepcanal_con`); se eliminó `09_sp_batch2_otros_placeholder.sql`. Falta: filas de `pro_batch2_filtros_estadisticas`, filas `CANT_REP_CANAL_CONTACTO`, DDL de `batch_cubo_persona11`, y pruebas en cluster |
| F2-5 | Ajustes en cubo_export, exportplano, exportlog y orquestador | Parcial | 70 % | Hecho: renombres en `cubo_export` (13-oct); orden real y firmas en el orquestador para PROCESACUBOS (13-oct); `exportlog` reescrito con el motor real (14-oct); orquestador conectado a los 4 SP de F2-4, con el cruce de parámetros B-08 replicado (15-oct). **El alcance creció**: además del layout fijo de `exportplano` ya documentado, F2-4 descubrió que `exportplano`/`cuboexport` deben materializar `v_ba2_campos_salida` y `vstg_batch2_pn/_pj/_pnpj`, de las que dependen TRANSPUESTA y Completitud_Canal (ver `GUIA_...` sección 3.5) |
| F2-6 | Actualizar documentación (`README.md`, `VERIFICACION.md`, `ddl/00_README.md`) | Parcial | 80 % | Actualizados el 13, 14 y 15-oct. Se creó `GUIA_PRUEBA_PRODUCTO_ESENCIAL.md` (14-oct) y `Bugs_Encontrados.md` (15-oct, 31 defectos del original inventariados). Pendiente: los resultados de la prueba en cluster |
| — | Pruebas en cluster Redshift (E2E y comparación con `Salidas/`) | Parcial (solo verificación local) | 12 % | Sin acceso a cluster. Verificado localmente: 36 pruebas unitarias de la Lambda, 5 000 cadenas de enmascaramiento contra el C original, estructura SQL balanceada, resolución de los 33 `CALL` entre procedures, y parseo con `sqlglot` del SQL dinámico **en sus dos niveles** (67 sentencias de nivel 1 + 5 generadas de nivel 2). Falta la ejecución real y la comparación byte a byte con `Salidas/` |

#### 3. Avance ponderado por esfuerzo (estimación)

| Bloque | Peso | Avance | Aporte |
|---|---|---|---|
| Análisis y diseño | 10 % | 100 % | 10,0 % |
| DDL | 10 % | 100 % | 10,0 % |
| Helpers + pipeline de exportación CSV | 10 % | 90 % | 9,0 % |
| SPs PROCESACUBOS (F2-3) | 30 % | 0 % | 0,0 % |
| SPs estadísticas/canal/transpuesta/log/plan (F2-4) | 20 % | 0 % | 0,0 % |
| Orquestador | 5 % | 50 % | 2,5 % |
| Documentación | 5 % | 40 % | 2,0 % |
| Pruebas y validación | 10 % | 0 % | 0,0 % |
| **Total** | **100 %** | | **≈ 33,5 %** |

Los pesos son una estimación de esfuerzo. La división entre F2-3 y F2-4 sigue la proporción de líneas de código fuente de cada grupo en `Sps_Batch.sql`.

#### 4. Tareas pendientes

| Prioridad | Tarea | Depende de |
|---|---|---|
| 1 | Migrar los 13 SPs de PROCESACUBOS, reemplazando `procedures/08_sp_batch2_filtros_placeholder.sql` | Nada (código fuente disponible) |
| 2 | Migrar los 6 SPs restantes, reemplazando `procedures/09_sp_batch2_otros_placeholder.sql` | Nada, salvo las llamadas a `PRO_BATCH2_ESTADISTICAS_CFG` |
| 3 | Ajustar el orquestador `procedures/10` (orden real, doble llamado a `FILTRO_E`, firmas) y revisar exportplano/exportlog | Tareas 1 y 2 |
| 4 | Actualizar `README.md`, `VERIFICACION.md` y `ddl/00_README.md` | Tareas 1–3 |
| 5 | Desplegar en un cluster, ejecutar E2E y comparar los CSV byte a byte con `Salidas/` | Acceso a cluster Redshift, bucket S3 e IAM Role |
| 6 | Paso de renombrado en S3 (Lambda/Glue) si el consumidor exige el nombre exacto del archivo | Decisión del negocio |

**Bloqueos que dependen del usuario** (insumos que no están en el workspace):

| Insumo faltante | Impacto |
|---|---|
| Código fuente de `PRO_BATCH2_ESTADISTICAS_CFG` | `ESTADISTICAS` queda incompleto (se llama 20+ veces) |
| Lógica de las 7 UDF Teradata (`Bach_Similitud_Dir_MZ`, `PorcSimilitud`, `Bach_Similitud_Tel`, `Bach_Similitud_email`, `DataMasking`, `DirDataMasking`, `RazonDataMasking`) | Las Lambda UDF están declaradas pero sin implementación; FILTRO_F y HOMOLOGACIONES no darán resultados reales |
| Filas de `BATCH_MOTOR_LOG` y `PRO_PLAN_EJECUCION` | Contienen SQL Teradata como datos; hay que reescribirlo a Redshift |
| Definición de `VstgBATCHCargaUbicEstandarizada` | Dependencia externa no creada |

---

### Prompt (usuario)
> Ahora continúa con la tarea F2-3: Migrar los 13 SPs de PROCESACUBOS, reemplazando procedures/08_sp_batch2_filtros_placeholder.sql y recuerda dejar evidencia en la bitácora

### F2-3 — Paso 1: convenciones y SP de referencia (Kiro)

- Se fijaron las convenciones comunes de la migración (quedan en la cabecera del nuevo archivo `procedures/08_sp_batch2_procesacubos.sql`):
  - **Firma estándar** `(p_lote, p_nombre_proceso, p_id_plantilla, p_id_solicitud [, otros])`. Se eliminan los parámetros de nombre de base de datos (`P_BDSTAGE`, `P_BDVISTA`, etc.) porque en Redshift los esquemas son fijos, y el `OUT P_ERROR` porque el error se propaga como excepción.
  - **SQL dinámico vía `rec_mtdat.sp_execstring_des`**, igual que el original, para conservar el mismo rastro paso a paso en `log_td_detalle`.
  - **Tablas de trabajo** en `rec_stage` con el mismo nombre en minúsculas (`CREATE TABLE ... DISTKEY(x) AS SELECT`), con `sp_drop_si_existe` previo.
  - **Mayúsculas/minúsculas**: las columnas Teradata son `NOT CASESPECIFIC`. Se define como requisito de despliegue crear la base Redshift con `COLLATE CASE_INSENSITIVE` (soportado por Redshift desde 2021, afecta `=`, `LIKE`, ordenamiento y agrupación; ver [AWS What's New](https://www.amazonaws.cn/en/new/2021/amazon-redshift-collation-column-level-overrides/)). Así la traducción de los filtros es literal.
- `PRO_BATCH2_FILTRO_A` migrado como SP de referencia (`LIKE ANY (subconsulta)` → `EXISTS ... LIKE`; `UPDATE ... FROM` sin alias en la tabla destino).
- Para los 12 SPs restantes (~6 000 líneas de origen) se reparte el trabajo en sub-agentes en paralelo, cada uno escribiendo un fragmento en `Redshift/procedures/_tmp_08/` con las mismas convenciones. Después se revisan, se consolidan en un solo archivo y se borra la carpeta temporal.

### F2-3 — Avance parcial (Kiro)

Fragmentos ya escritos en `Redshift/procedures/_tmp_08/` (9 de 13): FILTRO_A, B, C, D, G, HOMOLOGACIONES, I, H, J y ADICIONAR_INCON. Ningún sub-agente reportó faltantes de DDL, salvo una observación: `numero_id` es `VARCHAR(15)` en `batch_identificaciones_*`, pero `VARCHAR(20)` en el resto. Pendientes: FILTRO_E (código fuente ya leído), FILTRO_F y ADD_PORC_INSUMO. Los sub-agentes de esos tres fallaron por errores de red o límite de peticiones.

Dependencias nuevas de FILTRO_E: las vistas Teradata `<BDVISTA>.VU_PERSONA` y `BDM_VISTA.V_TIPO_PERSONA`, que no están en el workspace.

### Prompt (usuario)
> PRO_BATCH2_ESTADISTICAS_CFG, VstgBATCHCargaUbicEstandarizada, BATCH_MOTOR_LOG y PRO_PLAN_EJECUCION esto que son? código Teradata o SPs?

### Respuesta (Kiro)

Son 4 objetos de Teradata de tipos distintos. Solo uno es un SP.

| Objeto | Tipo | Quién lo usa | Qué falta | Cómo obtenerlo en Teradata |
|---|---|---|---|---|
| `REC_DATOS.PRO_BATCH2_ESTADISTICAS_CFG` | **Stored procedure** | `PRO_BATCH2_ESTADISTICAS` lo llama unas 20 veces, con un parámetro de modo distinto en cada llamada (`'SQL-PARAM'`, `'ESTADISTICAS'`, `'TMP_ESTADISTICAS'`, `'GENERO'`, `'CIIU'`, etc.) | Su código fuente (no está en `Sps_Batch.sql`) | `SHOW PROCEDURE REC_DATOS.PRO_BATCH2_ESTADISTICAS_CFG;` |
| `REC_STAGE.VstgBATCHCargaUbicEstandarizada` | **Vista** (prefijo `Vstg`) | `PRO_BATCH_ADD_PORC_INSUMO`, como universo de personas del insumo | Su definición | `SHOW VIEW REC_STAGE.VstgBATCHCargaUbicEstandarizada;` |
| `REC_STAGE.BATCH_MOTOR_LOG` | **Tabla de datos** cuyas filas guardan sentencias SQL (columnas `ID`, `TIPO`, `DATO`, `SQL_STRING`) | `FILTRO_C` (`TIPO='FILTRO-C'`), `CANTREPCANAL_CON` (`'CANT_REP_CANAL_CONTACTO'`), `ARCHIVO_LOG` (`'LOG'`). Leen las filas y ejecutan el texto | Las **filas** (el contenido), no la estructura | `SELECT * FROM REC_STAGE.BATCH_MOTOR_LOG ORDER BY TIPO, ID;` |
| `REC_STAGE.PRO_PLAN_EJECUCION` | **Tabla de datos**, aunque empieza por `PRO_` (columnas `ID`, `PARTE`, `CAMPO`, `SQL_VALOR`) | `PRO_BATCH2_PLAN_EJECUCION_SHELL`, que arma el plan de pasos ejecutando el SQL guardado en las filas | Las **filas** | `SELECT * FROM REC_STAGE.PRO_PLAN_EJECUCION ORDER BY PARTE, ID;` |

Las dos tablas guardan SQL escrito en sintaxis Teradata. Una vez exportadas, ese SQL hay que reescribirlo a Redshift. Los SP Redshift ya replican el motor que lo lee y lo ejecuta.

---

### Prompt (usuario)
> Sí, continúa tú mismo con esos 3 mientras yo consigo los insumos faltantes. Al finalizar, recuerda dejar la actualización en la bitácora

### F2-3 — Cierre: 13 de 13 SPs de PROCESACUBOS migrados (Kiro)

Kiro migró directamente los 3 SPs que faltaban (FILTRO_E, FILTRO_F y ADD_PORC_INSUMO), sin sub-agentes. Después consolidó los 13 en un solo archivo.

**Resultado**
- Nuevo `Redshift/procedures/08_sp_batch2_procesacubos.sql` (~3 300 líneas, 13 procedures, en el orden real de ejecución). Lleva una cabecera con las convenciones comunes.
- Se eliminó `08_sp_batch2_filtros_placeholder.sql`. Su helper `sp_batch2_filtro_placeholder` se trasladó a `09_sp_batch2_otros_placeholder.sql`, porque los placeholders de F2-4 lo siguen usando. De paso se corrigió su `RAISE`, que usaba una expresión como argumento.
- Se borró la carpeta temporal `procedures/_tmp_08/`.

| SP Teradata | Procedure Redshift | Firma (además de `p_lote, p_nombre_proceso`) | Bugs del original replicados y documentados |
|---|---|---|---|
| FILTRO_A | `sp_batch2_filtro_a` | plantilla, solicitud | Texto de log copiado |
| FILTRO_B | `sp_batch2_filtro_b` | plantilla, solicitud | — |
| FILTRO_C | `sp_batch2_filtro_c` | plantilla, solicitud | Motor `BATCH_MOTOR_LOG`: faltan las filas |
| FILTRO_D | `sp_batch2_filtro_d` | plantilla, solicitud | Cubo no mapeado → SQL NULL; truncamiento a 1000 |
| FILTRO_E | `sp_batch2_filtro_e` | plantilla, solicitud, `p_tipo_persona` | `CUBO_DIRECCIONES`/`CUBO_CELULARES` no coinciden con el UPDATE. **Nuevo:** la llamada 'J' borra las marcas de la llamada 'N' |
| FILTRO_F | `sp_batch2_filtro_f` | plantilla, solicitud | No resetea FILTRO_F; sin `PMD` → FLAG = 1 |
| FILTRO_G | `sp_batch2_filtro_g` | plantilla, solicitud | UPDATE sobre los 6 cubos en cada iteración |
| HOMOLOGACIONES | `sp_batch2_homologaciones` | plantilla, solicitud | MIN_ID / QUALIFY puede generar SQL inválido |
| FILTRO_I | `sp_batch2_filtro_i` | (ninguno) | — |
| FILTRO_H | `sp_batch2_filtro_h` | plantilla, solicitud | CASE sin ELSE; el cubo punto de interés no recalcula |
| FILTRO_J | `sp_batch2_filtro_j` | (ninguno) | Depende de la collation (`'Correo'` vs `'correo'`) |
| ADD_PORC_INSUMO | `sp_batch2_add_porc_insumo` | plantilla, solicitud (el original las recibe al revés; se usan por nombre) | Duplicados si hay varias filas en `BATCH_SALIDAS_CAMPOS` |
| ADICIONAR_INCON | `sp_batch2_adicionar_incon` | plantilla, solicitud | CAST a BIGINT sin protección |

**Decisiones de traducción nuevas (quedan en la cabecera del archivo)**
- `CAST(decimal AS INTEGER)`: Teradata trunca. Redshift redondea o trunca según el parámetro `enable_numeric_rounding` ([AWS docs](https://docs.aws.amazon.com/redshift/latest/dg/r_enable_numeric_rounding.html)). Se usa `CAST(TRUNC(x) AS INTEGER)`.
- Orden de NULL: Teradata trata NULL como el valor más bajo. Se escribe `NULLS FIRST`/`NULLS LAST` explícito en las ventanas.
- Alias del SELECT con el mismo nombre que una columna: en Teradata gana la columna. Esto afecta a `ORDEN_PRIORIDAD` en ADD_PORC_INSUMO y a `SIMILITUD` en FILTRO_F.
- MERGE solo de actualización → `UPDATE ... FROM`, porque Redshift exige `WHEN NOT MATCHED`.
- `CHAR(x)`/`CHARS(x)` de Teradata es el largo de la cadena → `LEN(x)`.
- ADD_PORC_INSUMO: de la vista `VstgBATCHCargaUbicEstandarizada` solo se usa `ID_BURO_PERSONA`; el resultado no cambia.

**Otros archivos ajustados**
- `10_sp_batch2_proceso_batch2.sql`: se reescribió solo el bloque PROCESACUBOS, con las firmas nuevas y el orden real (A, B, C, D, E('N'), E('J'), F, G, HOMOLOGACIONES, I, H, J, ADD_PORC, ADICIONAR_INCON). El resto del orquestador sigue en F2-5.
- `ddl/05_tablas_control.sql`: `numero_id` pasa a `VARCHAR(20)` en `batch_identificaciones_validas`/`_incons`.
- `ddl/07_tablas_dependencias_sps.sql`: se documentaron las dependencias externas `rec_vista.vu_persona` y `rec_vista.v_tipo_persona` (FILTRO_E).
- `README.md`: orden de despliegue actualizado (incluye `ddl/07`, `ddl/08` y el nuevo `08_sp_batch2_procesacubos.sql`), requisito `COLLATE CASE_INSENSITIVE` y la sección de placeholders reducida a F2-4.

**Verificación realizada:** no hay cluster Redshift ni parser PL/pgSQL disponible (no hay Python instalado). Se hizo un chequeo automático por fragmento: un `CREATE PROCEDURE` y un `$$;` cada uno, comillas balanceadas, sin caracteres no ASCII. Además se buscaron patrones de riesgo (números concatenados sin CAST, alias en el destino de UPDATE/DELETE, `EXECUTE ... INTO`), sin hallazgos. **No se pudo verificar en ejecución:** CTAS con `WITH RECURSIVE` + `QUALIFY` (FILTRO_D, HOMOLOGACIONES, FILTRO_E), `ANALYZE` dentro de un SP, las Lambda UDF dentro de CTAS, ni los resultados frente a Teradata.

**Insumos que siguen faltando para estos 13 SPs:** la lógica de las 7 UDF Teradata (para las Lambda), las filas `FILTRO-C` de `BATCH_MOTOR_LOG` y las vistas `VstgBATCHCargaUbicEstandarizada`, `VU_PERSONA` y `V_TIPO_PERSONA`.

**Avance global actualizado: ~63 %.** F2-3 pasa a ~95 % (código completo; faltan los insumos externos y las pruebas). El orquestador sube a ~70 % y la documentación a ~50 %. Siguiente tarea: F2-4 (los 6 SPs de `09_sp_batch2_otros_placeholder.sql`).


---

## Sesión: 2026-10-14

### Prompt (usuario)
> Lee la bitácora y analiza el código migrado hasta ahora. Con esto, crea una guía de todo lo que se requiere, paso a paso, para hacer una prueba del producto "Esencial" en Redshift. Ten en cuenta que ya contamos con un cluster de Redshift pero aún no se han creado allí todas las tablas requeridas. Créalo como un documento md independiente y asegúrate de incluir además de los pasos para ejecutar dicha prueba, las cosas que hacen falta para llevarla a cabo.

### Aclaración pedida por Kiro y respuesta del usuario
Kiro preguntó qué se entendía por producto "Esencial" (no aparece documentado en el workspace). El usuario respondió:
- La prueba es de la etapa de explotación en Teradata: se carga un archivo (normalmente CSV) usando la configuración sincronizada (separador, posiciones/campos, plantilla); el batch corre contra el modelo precalculado de Reconocer, valida identidad, y genera archivos planos de salida (con datos, sin datos, inconsistencias).
- Definición de "Esencial": permite actualizar datos de contacto para campañas de mantenimiento de cartera y cobranza; entrega hasta 3 direcciones físicas, 3 teléfonos fijos, 2 celulares y 2 correos electrónicos, según disponibilidad.

### Respuesta (Kiro) — Guía creada: `Redshift/GUIA_PRUEBA_PRODUCTO_ESENCIAL.md`

Antes de escribir la guía se releyó el código migrado (`ddl/02,03,04,05,06,07,08`, `procedures/03,04,07,09,10`, `DDL.sql`, `P0033_BATCH2_VALIDAR_ARCHIVOS_111.BTQ`) para verificar con precisión qué soporta hoy el pipeline frente a los límites 3/3/2/2 de Esencial.

**Hallazgos clave que entraron en la guía:**
- El límite 3 direcciones/3 teléfonos/2 celulares/2 correos se configura, en el diseño original, vía `BATCH_SALIDAS_CAMPOS.CANTIDAD_MAX_CAMPO` (una fila de catálogo por campo/repetición), no como parámetro de ejecución.
- **Gap real detectado en `sp_batch2_exportplano`**: el procedure NO lee `batch_salidas_campos` para armar el layout de columnas; usa un `SELECT` fijo hardcodeado con solo 1 teléfono, 1 dirección y 1 correo, y **sin canal celular en absoluto**. Tal como está hoy, no puede producir una salida fiel a Esencial.
- **Gap en las tablas pivote**: `w_cubo_direccion` solo llega a `_002` (hacen falta 3); `w_cubo_telefono` ya llega a `_005` (alcanza); `w_cubo_celular` y `w_cubo_correo` llegan exacto a `_002` (alcanzan para 2).
- No existe un catálogo real de "productos"/plantillas comerciales en el workspace; se propone usar un `id_plantilla`/`id_solicitud` de prueba dedicados y cargarlos a mano.
- No existe aún un script de carga masiva (`COPY` desde S3) del CSV de insumo hacia las tablas `batch_cubo_*`; todo lo migrado asume esas tablas ya pobladas (confirmado también en `README.md`).
- Se repasaron los bloqueos ya conocidos (Lambda UDF sin implementación real, vistas externas `vstgbatchcargaubicestandarizada`/`vu_persona`/`v_tipo_persona`, collation `CASE_INSENSITIVE` requerida, IAM Role + bucket S3 para `UNLOAD`) y se incorporaron como prerrequisitos de infraestructura.

**Contenido del documento creado:**
1. Definición de Esencial y su implicación técnica (con el gap de `exportplano` explicado).
2. Tabla de estado real de cada componente migrado, enfocada en si sirve o no para esta prueba.
3. Lista de lo que falta, en 4 bloques: (3.1) ampliar `w_cubo_direccion` a `_003`; (3.2) extender `sp_batch2_exportplano` para incluir celular y repetir cada canal 3/3/2/2 (idealmente dinámico desde `batch_salidas_campos`); (3.3) insumos de UDF/vistas externas que no bloquean pero afectan calidad; (3.4) infraestructura AWS (bucket S3, IAM Role, Lambda, collation, formato real del insumo).
4. Datos de prueba sugeridos: INSERT de ejemplo para `batch_solicitud_batch`, `batch_datos_generales`, `batch_salidas_campos` (con `cantidad_max_campo` = 3/3/2/2) y nota sobre cubos de contacto con más registros de los permitidos para probar el truncamiento.
5. Paso a paso de despliegue del DDL y procedures completo (orden de los `\i`, con nota de collation y de qué hacer si las Lambda UDF no están listas).
6. Dos opciones para la carga del archivo de insumo de prueba (INSERT directo vs. `COPY` desde S3, esta última pendiente de escribir como script).
7. Comando de ejecución del orquestador (`CALL sp_batch2_proceso_batch2`) y cómo verificar resultados (log_td_detalle, archivos en S3, comparación contra una muestra real si existe).
8. Checklist resumido de pendientes.
9. Recordatorio de lo que queda fuera de alcance de esta prueba puntual (placeholders F2-4, `ESTADISTICAS_CFG`, renombrado de archivos en S3).

**No se modificó código** en esta sesión; la guía documenta los cambios de código recomendados (secciones 3.1 y 3.2) como tareas a realizar antes de ejecutar la prueba, pero no los implementa todavía.

---

### Prompt (usuario)
> Lee la bitácora del trabajo realizado y retoma lo que quedó pendiente del paso F2-3, usando las funciones faltantes que están en `FuncionesUDF/` y el otro insumo aportado en `Dlls-Batch/`. Avanza en el propósito de migración a Redshift y deja evidencia de los avances realizados en el documento de bitácora.

### Prompt (usuario, continuaciones)
> Parece que ocurrió un error, qué alcanzaste a hacer? terminaste el paso F2-3 o en qué porcentaje quedó? / Usa la información que tienes en el contexto y verifica si la tarea F2-3 ya se completó en su totalidad o qué queda faltando / Sí, actualiza la bitácora y hazme una nueva lista con los insumos que faltan para solicitarlos mañana

### Respuesta (Kiro) — F2-3 con las UDF en C y los DDL/filas de `Dlls-Batch`

**Incidente de la sesión.** La terminal devolvió salidas truncadas y repetidas, y la sesión se cortó antes de dejar registro. Lo que hay en este bloque se reconstruyó releyendo los archivos y volviendo a correr las verificaciones, no de memoria.

**Insumos leídos**
- `FuncionesUDF/` (16 archivos): código C y `.BTQ` de `Bach_Similitud_Dir_MZ`, `Bach_Similitud_Dir_VIA`, `Bach_Similitud_Tel`, `Bach_Similitud_email`, `PorcSimilitud`, `DataMasking`, `DirDataMasking` y `RazonDataMasking`.
- `Dlls-Batch/Dll_Btach.csv`: código de `PRO_BATCH2_ESTADISTICAS_CFG`, definición de la vista `VstgBATCHCargaUbicEstandarizada`, DDL de `BATCH_MOTOR_LOG` y sus 18 filas `TIPO='LOG'`.
- `Dlls-Batch/Dll_Btach2.csv`: DDL de `PRO_PLAN_EJECUCION` y sus 12 filas `PARTE='ITERADOR'`.
- Contraste con `Sps_Batch.sql` (`PRO_BATCH2_ARCHIVO_LOG`, `PRO_BATCH2_PLAN_EJECUCION_SHELL`), con `P0033_BATCH2_EXPORTLOG_111/130/140` y con las muestras de `Salidas/`.

**Estado de los pendientes de F2-3 que había al cierre del 13-oct**

| Pendiente | Estado | Detalle |
|---|---|---|
| Lógica de las 7 UDF | Hecho | 4 de similitud en una Lambda Python (`Redshift/lambda/udf_similitud/`); 3 de enmascaramiento como SQL UDF en `ddl/08` |
| Vista `VstgBATCHCargaUbicEstandarizada` | Hecho, con dependencias | `ddl/09`, vista late-binding. Lee tablas de P0034 que no están migradas |
| Filas `FILTRO-C` de `BATCH_MOTOR_LOG` | **Falta** | `Dll_Btach.csv` solo trae las filas `LOG` |
| Vistas `VU_PERSONA` y `V_TIPO_PERSONA` (FILTRO_E) | **Falta** | No venían en los insumos |
| Confirmar `editdistance_u` | **Falta** | Su código (`loadParamsAcepAut.h`) no está en el workspace |
| Pruebas en cluster | **Falta** | Sin acceso al cluster |

**F2-3 queda en ~97 %.** El código de los 13 SPs está completo. Lo que falta son insumos externos y la prueba en cluster.

**Archivos creados o modificados**
- Nuevos: `Redshift/lambda/udf_similitud/{lambda_function.py, test_lambda_function.py, casos_validacion_teradata.sql, casos_validacion_redshift.sql}`, `Redshift/ddl/09_vistas_dependencias_sps.sql`, `Redshift/datos/01_catalogos_motor.sql`, `Redshift/procedures/09b_sp_batch2_motores_sql.sql`.
- Reescritos: `ddl/08_funciones_udf.sql`, `procedures/05_sp_batch2_exportlog.sql`.
- Ajustados: `ddl/05` (`batch2_shells_planejecucion` con la estructura real, `batch2_homologacion.descripcion_campo`), `ddl/07` (`batch2_shells_config` nueva, `pro_batch2_filtros_estadisticas` con `parte`/`orden`/`criterio` de 65 535), `procedures/02` (helper `sp_drop_tabla_por_nombre`), `08_procesacubos` (solo comentarios), `09_placeholder` (se elimina el placeholder `sp_batch2_plan_ejecucion`), `10_proceso_batch2` (llama al plan real y al nuevo exportlog).
- Documentación: `Redshift/README.md`, `Redshift/VERIFICACION.md`, `Redshift/ddl/00_README.md`, `Redshift/GUIA_PRUEBA_PRODUCTO_ESENCIAL.md`.

**Hallazgos en las UDF que cambian resultados**
- `PorcSimilitud` declara `VARCHAR(20)`. FILTRO_F le pasa direcciones completas, así que en Teradata solo se comparaban los primeros 20 caracteres. La Lambda lo replica.
- `Bach_Similitud_Dir_MZ` puede devolver más de 100 (un número repetido en la bodega se cuenta varias veces) o menos de 0; el CASE de FILTRO_F ya lo acota.
- Con insumo vacío, el C divide por cero y devuelve -2147483648 (x86-64). Se replica.
- `DataMasking` con 3 caracteres o menos: el C devuelve un buffer sin inicializar. Decisión: devolver el dato sin cambios. Afecta buzones de correo cortos en solicitudes de prueba.
- Los tres enmascaramientos usan `sprintf(salida, cadena)`: un `%` en el dato corrompe la salida en Teradata. No se replica.
- `Bach_Similitud_Dir_VIA` no se migró: ningún SP de BATCH2 la llama y depende de `AddressNormalization.h`, que no está.

**Supuestos que quedan por confirmar**
- `editdistance_u` = Damerau-Levenshtein OSA con costos 1 (los 4 costos están en la llamada del C). Si Teradata da otro resultado en `casos_validacion_teradata.sql`, se ajusta `edit_distance` en la Lambda.
- Teradata trunca en silencio los argumentos al largo del `VARCHAR` del parámetro. Si da error en esos casos, se quita `TRUNCAR_A` de la Lambda.
- El parámetro `process` del orquestador (`P0033_PROCESO_BATCH2.par`) se infirió como `'ITERADOR'`, porque es la única `PARTE` con filas. El delimitador del log se infirió como `','` a partir de las muestras.

**Motores migrados (tarea F2-4, parte)**
- `PRO_BATCH2_ARCHIVO_LOG` → `sp_batch2_archivo_log` y `sp_batch2_exportlog`. Replico dos comportamientos del original, confirmados con las 4 corridas de `Salidas/BATCH_SOLICITUD_BATCH.ARCHIVO_LOG`: la fila 13 del motor sobrescribe "CODIGO SUSCRIPTOR" (copia mal una sentencia), y "REGISTROS GRABADOS" siempre vale 0.
- `PRO_BATCH2_PLAN_EJECUCION_SHELL` → `sp_batch2_plan_ejecucion_shell`. `PRO_BATCH2_ESTADISTICAS_CFG` → `sp_batch2_estadisticas_cfg`. Aún no lo llama ningún SP, porque `ESTADISTICAS` sigue como placeholder.
- Los DROP del motor de plan pasan a `DROP TABLE IF EXISTS`: en un cluster nuevo, el DROP sin `IF EXISTS` de la primera corrida habría fallado.
- Diferencia con Teradata: `UNLOAD` no puede agregar al archivo histórico ni fijar el nombre exacto. El paso 140 del log (concatenar al historial) queda para el mismo proceso externo que renombra los CSV.

**Verificación (local, sin cluster)**
- Lambda: 36 pruebas unitarias OK (`python -B -m unittest test_lambda_function.py`). Incluyen los casos de los `.BTQ`, NULL, el contrato JSON de Redshift, semántica de C y la distancia contra una implementación independiente (3 000 pares aleatorios).
- Enmascaramiento SQL contra el port literal del C: 5 000 cadenas aleatorias, sin diferencias.
- Estructura de los 12 archivos SQL tocados: comillas, paréntesis y `$$` balanceados; igual número de `CREATE PROCEDURE` y de cierres.
- Las 30 sentencias de `datos/01_catalogos_motor.sql` y la vista de `ddl/09` pasan el parser `sqlglot` 30.23.0 (dialecto Redshift). `sqlglot` no valida nombres de tablas ni funciones.
- **No verificado:** ejecución en Redshift, `editdistance_u` real, ni equivalencia byte a byte con Teradata.

**Riesgo de despliegue.** Los `CREATE TABLE IF NOT EXISTS` no modifican tablas que ya existan. Si en el cluster ya se corrió una versión anterior de `ddl/05` o `ddl/07`, hay que borrar y recrear antes de cargar `datos/01`: `batch_archivo_log` (el `id` ya no es IDENTITY), `batch2_shells_planejecucion`, `pro_plan_ejecucion`, `pro_batch2_filtros_estadisticas` y `batch2_homologacion`.

**Avance global estimado: ~69 %** (63 % al cierre del 13-oct).

| Bloque | Peso | Avance | Aporte |
|---|---|---|---|
| Análisis y diseño | 10 % | 100 % | 10,0 % |
| DDL | 10 % | 100 % | 10,0 % |
| Helpers + pipeline de exportación CSV | 10 % | 95 % | 9,5 % |
| F2-3 PROCESACUBOS | 30 % | 97 % | 29,1 % |
| F2-4 estadísticas / canal / transpuesta / log / plan | 20 % | 12 % | 2,4 % |
| Orquestador | 5 % | 85 % | 4,3 % |
| Documentación | 5 % | 60 % | 3,0 % |
| Pruebas y validación | 10 % | 10 % | 1,0 % |
| **Total** | **100 %** | | **≈ 69 %** |

F2-4 pasa de 0 % a ~12 % porque `ARCHIVO_LOG` y `PLAN_EJECUCION_SHELL` están hechos; siguen pendientes `ESTADISTICAS` (el SP más largo), `TRANSPUESTA`, `Completitud_Canal` y `CANTREPCANAL_CON`, cuyo código ya está en `Sps_Batch.sql`.

### Lista de insumos pendientes (para solicitar)

**A. Equipo Teradata: cierran F2-3 y F2-4**

| # | Insumo | Para qué | Cómo obtenerlo |
|---|---|---|---|
| 1 | Filas de `BATCH_MOTOR_LOG` con `TIPO` distinto de `LOG` (`FILTRO-C` y `CANT_REP_CANAL_CONTACTO`) | Sin ellas FILTRO_C no hace nada y no se puede migrar `CANTREPCANAL_CON` | `SELECT * FROM REC_STAGE.BATCH_MOTOR_LOG WHERE TIPO <> 'LOG' ORDER BY TIPO, ID;` |
| 2 | `REC_DATOS.PRO_BATCH2_FILTROS_ESTADISTICAS`: DDL y todas las filas | Es lo que ejecuta `ESTADISTICAS_CFG` en ~20 modos; sin esto no se puede migrar `ESTADISTICAS` | `SHOW TABLE REC_DATOS.PRO_BATCH2_FILTROS_ESTADISTICAS;` y `SELECT * ... ORDER BY PARTE, ORDEN;` |
| 3 | `REC_STAGE.BATCH2_SHELLS_CONFIG`: DDL y filas | Sin filas, el plan de ejecución queda vacío | `SHOW TABLE ...;` y `SELECT * ... ORDER BY ORDEN_ID, ORDEN_IDLL, ORDEN_IDLLL;` |
| 4 | Vistas `VU_PERSONA`, `BDM_VISTA.V_TIPO_PERSONA` y `BDM_VISTA.V_TIPO_IDENTIFICACION` | FILTRO_E y el conteo "REGISTROS LEIDOS" del log | `SHOW VIEW ...;` de cada una |
| 5 | Salida de correr `casos_validacion_teradata.sql` en Teradata | Confirma el supuesto de `editdistance_u` y el truncamiento de argumentos | Ejecutar el script y enviar el resultado. Alternativa: el código de `editdistance_u` (`loadParamsAcepAut.h` y su `.c`) |
| 6 | Código de `REC_DATOS.SP_EXECSTRING_DES` | Confirmar qué escribe en `LOG_TD_DETALLE` (hoy se deduce de su uso) | `SHOW PROCEDURE REC_DATOS.SP_EXECSTRING_DES;` |
| 7 | Archivos `.par`: `P0033_PROCESO_BATCH2.par`, `P0033_BATCH2_EXPORTLOG.par`, `P0033_BATCH2_EXPORTPLANO.par` | Confirmar `process` (hoy `'ITERADOR'`), `DELIMITADOR` y `FileName` del log | Copiar los archivos de la carpeta de parámetros |
| 8 | Confirmar que `PRO_PLAN_EJECUCION` no tiene otras `PARTE` | El CSV solo trajo `ITERADOR` | `SELECT DISTINCT PARTE FROM REC_STAGE.PRO_PLAN_EJECUCION;` |

**B. Equipo Teradata: necesarios para correr la prueba de punta a punta**

| # | Insumo | Para qué | Cómo obtenerlo |
|---|---|---|---|
| 9 | `REC_STAGE.BATCH2_HOMOLOGACION`: DDL y filas (no está en `DDL.sql`; su estructura es inferida) | Define el layout de campos de salida y alimenta FILTRO_D, G, H y HOMOLOGACIONES | `SHOW TABLE ...;` y `SELECT * ...;` |
| 10 | Configuración de una solicitud real: filas de `BATCH_SOLICITUD_BATCH`, `BATCH_DATOS_GENERALES`, `BATCH_SALIDAS_CAMPOS`, `BATCH_PORCENTAJES_FILTROS` y `BATCH_DIRECCION_FILTROS`. Ideal: la solicitud 4421 de `Salidas/`, o una de Esencial con `CANTIDAD_MAX_CAMPO` 3/3/2/2 | Datos de prueba reales en lugar de los inventados de la guía | `SELECT * ... WHERE ID_SOLICITUD = <n>;` |
| 11 | Archivo de insumo (CSV) que generó las muestras de `Salidas/` y su `.par` | Comparar los CSV de Redshift contra los de Teradata | Copiar el archivo |
| 12 | Cómo se llenan los cubos y el insumo: scripts de P0032 (`P0032_BATCH_GENERACUBO`, `_PUNTO_INT`, `P0032_BATCH_EXPL_DE_PUNTOS_DE_INT`), o una muestra exportada de `BATCH_CUBO_*` y `STG_INSUMO_BATCH_VALIDACION` | Sin datos en los cubos no hay nada que filtrar | Scripts, o `SELECT *` de las tablas para la solicitud elegida |
| 13 | Proceso P0034: scripts (`P0034_CARGA_INSUMO_STANDARD`, `P0034_EstandarizacionUbicacion`, `P0034_UBICACION_ESTANDARIZADA`) o DDL de `BATCH_tmp_CARGA_INSUMO_STANDARD`, `BATCH_DireccionFisica_Estandarizada`, `BATCH_TelefonoFijoEstandarizado`, `BATCH_TelefonoMovil_Estandarizado`, `BATCH_Emails_Estandarizados`, `REC_VISTA.V_Tipo_Ubicacion` y `REC_VISTA.VU_Geografia` | Alimentan la vista de `ADD_PORC_INSUMO` | `SHOW TABLE/VIEW` de cada una |
| 14 | Vistas `v_evento_entrega_dato`, `v_cod_entrega_dato` y `Vstg_BUROPERS_TMP` (prioridad baja) | Campo "CODIGO SUSCRIPTOR" del log; en las 4 muestras sale vacío | `SHOW VIEW ...;` |

**C. Infraestructura y decisiones (de tu lado)**

| # | Tema | Detalle |
|---|---|---|
| 15 | Acceso al cluster | Usuario con permiso para crear esquemas, funciones externas y procedimientos. Confirmar que la base se creó con `COLLATE CASE_INSENSITIVE`; si no, hay que recrearla |
| 16 | AWS | Bucket S3 y IAM Role para `UNLOAD`; IAM Role para invocar Lambda; permiso para desplegar la Lambda (Python 3.12, sin dependencias) |
| 17 | Nombre exacto de los archivos | Decidir si el consumidor exige el nombre sin sufijo y el log acumulado (append). Si sí, hace falta un paso externo (Lambda o Glue) |
| 18 | `DataMasking` con 3 caracteres o menos | Confirmar con negocio si dejar el dato sin cambios es aceptable en solicitudes de prueba |

**No se necesitan:** `Bach_Similitud_Dir_VIA` (ningún SP de BATCH2 la llama) ni el wrapper `BDM-DWH_Exec_Process_batch.sh` (en Redshift no hay shells que lanzar).

---

## Sesión: 2026-10-15

### Prompt (usuario)
> Actualiza la tabla "2. Estado por tarea" del archivo de bitácora con los nuevos porcentajes de avance. Para eso, lee este mismo documento para tener claro lo que se hizo hasta la sesión de ayer 14/Oct

### Respuesta (Kiro)
Se actualizó la tabla "2. Estado por tarea" (sección del resumen del 2026-10-13) con el avance registrado al cierre del 14-oct, dejando una nota de trazabilidad al inicio de la tabla. Cambios: F2-3 de 0 % a 97 %; F2-4 de 0 % a 12 %; F2-5 de ~25 % a 85 %; F2-6 de 0 % a 60 %; pruebas en cluster de 0 % a 10 % (solo verificación local). F2-1 y F2-2 siguen en 100 %, con nota de los ajustes adicionales del 14-oct.

### Prompt (usuario)
> Ahora revisa si con el contenido entregado ayer en `FuncionesUDF/` y en `Dlls-Batch/` se puede avanzar en la tarea F2-4

### Respuesta (Kiro) — Revisión de insumos frente a F2-4

**Conclusión: los insumos entregados ayer no desbloquean nada nuevo en F2-4.** Su único aporte a esta tarea (el código de `PRO_BATCH2_ESTADISTICAS_CFG`) ya se consumió en la sesión del 14-oct. Pero F2-4 **sí puede avanzar**, por una razón distinta: 2 de los 4 SPs pendientes nunca estuvieron bloqueados; su fuente está en `Sps_Batch.sql` desde el 13-oct.

**Verificación hecha** (no de memoria): lectura completa de los 2 CSV de `Dlls-Batch/`, búsqueda de llamadas a UDF en todo `Sps_Batch.sql` con número de línea, lectura de los 4 SPs pendientes en `Sps_Batch.sql` (líneas 6161–9229) y un sub-agente de inventario de dependencias sobre esos mismos rangos.

#### Aporte real de cada carpeta a F2-4

| Insumo | Contenido verificado | Aporte a F2-4 |
|---|---|---|
| `FuncionesUDF/` (16 archivos) | 8 UDF en C + `.BTQ` | **Ninguno.** Las 7 UDF solo se invocan en `FILTRO_F` (líneas 2051, 2062, 2239, 2380, 2548) y `ADD_PORC_INSUMO` (5129, 5142, 5154, 5187, 5254), ambos de F2-3. Los 4 SPs pendientes de F2-4 no llaman ninguna UDF |
| `Dll_Btach.csv` | Código de `PRO_BATCH2_ESTADISTICAS_CFG`, vista `VstgBATCHCargaUbicEstandarizada`, DDL de `BATCH_MOTOR_LOG` y 18 filas `TIPO='LOG'` | **Solo `ESTADISTICAS_CFG`**, ya migrado el 14-oct (`procedures/09b`). Las filas `LOG` sirvieron a `ARCHIVO_LOG`, que ya estaba hecho. Se confirma que **no trae** filas `TIPO='CANT_REP_CANAL_CONTACTO'` |
| `Dll_Btach2.csv` | DDL de `PRO_PLAN_EJECUCION` + 12 filas `PARTE='ITERADOR'` | **Ninguno nuevo.** Alimentó `PLAN_EJECUCION_SHELL`, ya migrado el 14-oct |

#### Estado de los 4 SPs que faltan en F2-4

| SP Teradata | Líneas | ¿Migrable hoy? | Dependencias que faltan |
|---|---|---|---|
| `PRO_BATCH2_TRANSPUESTA` (7797–8331) | ~535 | **Sí** | Ninguna externa. Usa `v_ba2_Campos_Salida`, `Vstg_Batch2_PN/PJ/PNPJ` y tablas de trabajo propias (ver hallazgo abajo) |
| `PRO_Batch2_Completitud_Canal` (8332–8958) | ~627 | **Sí** | Ninguna externa. Usa `v_ba2_Campos_Salida`, `Vstg_Batch2_*`, `rec_stage.secuencia` (ya en `ddl/07`) y `w_borrar_002`/`w_Ejecutor`/`tabla_w1`/`tabla_w2`, cuyo DDL está en `P0033_BATCH2_CANALCONTACTO_111.BTQ` |
| `PRO_BATCH2_ESTADISTICAS` (6161–7796) | ~1 636 | Esqueleto sí; funcionalmente no | Filas de `REC_DATOS.PRO_BATCH2_FILTROS_ESTADISTICAS` (doble uso: criterios `CAMPO='CAUSAL'`/`'ESTADO'` en 4 UPDATE inline, y el SQL de las 17 `PARTE` que ejecuta `ESTADISTICAS_CFG`). Además filas de `rec_vista.tipo_identificacion` y datos de `batch_valform_st2/st4` (P0037) |
| `PRO_BATCH2_CANTREPCANAL_CON` (8959–9229) | ~271 | Motor sí; funcionalmente no | Filas de `BATCH_MOTOR_LOG` con `TIPO='CANT_REP_CANAL_CONTACTO'` (ahí vive toda la lógica). Además DDL de `BATCH_Cubo_Persona11` (no está en ningún archivo del workspace) y las vistas `vu_persona`/`v_tipo_persona` (ya pedidas para FILTRO_E) |

#### Hallazgo nuevo: dos objetos que la migración nunca creó

`TRANSPUESTA` y `Completitud_Canal` consumen `v_ba2_Campos_Salida` y `Vstg_Batch2_PN/PJ/PNPJ`. **Ninguno de los dos existe en `Redshift/`**: se buscó `CREATE VIEW`/`CREATE TABLE` en `procedures/03_sp_batch2_cubo_export.sql` y `04_sp_batch2_exportplano.sql` y no hay ninguno; esos nombres solo aparecen en comentarios. En Teradata los crean los pasos BTEQ (`CUBOEXPORT_111.BTQ` línea 1339 para `v_ba2_Campos_Salida`, líneas 1134 y 1225 para `vstg_INCONSIS_PNPJ`), mientras que el `exportplano` de Redshift va directo de las tablas pivote a un `SELECT` fijo hacia `UNLOAD`.

Es el mismo vacío ya documentado en `GUIA_PRUEBA_PRODUCTO_ESENCIAL.md` (sección 3.2): el layout de salida no se arma desde `batch_salidas_campos`. Migrar `v_ba2_Campos_Salida` como vista real resolvería a la vez ese gap de F2-5 y la dependencia de estos dos SPs. Sus definiciones sí están en el workspace, así que no es un bloqueo, es trabajo.

#### Bugs del original detectados en estos 4 SPs (a replicar o corregir, por decidir)

- `Completitud_Canal`: el bloque de DIRECCION está muerto. Línea 8792 hace `SET V_ITERA = 1` y 8797 condiciona `WHILE ( V_ITERA=2 )`, así que las líneas 8799–8945 nunca corren y solo queda poblada `tabla_w1` (teléfono). Ya estaba anotado el 13-oct; se confirma con el fuente.
- `ESTADISTICAS`, bloque `ID_NE` (~6830–6850): el `INNER JOIN ... PRO_BATCH2_FILTROS_ESTADISTICAS CR ON TRIM(TW.CAUSAL)=''05''` no tiene predicado contra `CR` → producto cartesiano. El `COUNT(*)` queda multiplicado por el número de filas del catálogo que cumplan el `WHERE`. Solo da bien si existe exactamente una fila con `CAMPO='CAUSAL'` y `VALOR1='ID_NE'`.
- `ESTADISTICAS`: mezcla de esquemas en el mismo `UNION ALL` (`'||P_BDSTAGE||'.vstg_INCONSIS_PNPJ_TABLA` en 6787 vs `REC_STAGE.VSTG_INCONSIS_PNPJ_TABLA` hardcodeado en 6793). Se rompe si `P_BDSTAGE <> REC_STAGE`.
- `ESTADISTICAS`: `BATCH2_ESTADISTICAS_TMP` se dropea pero nunca se crea.
- `ESTADISTICAS`, vista `VSTG_BATCH_ESTADISTICAS_EXP`: PARTE_11 y PARTE_12 leen el mismo `IDENTIFICADOR='CIUDAD_DIR_TOTAL'`; por simetría PARTE_12 debería ser `CIUDAD_TEL_TOTAL`.
- `TRANSPUESTA`: `BACTH_CAMPOS_2` se crea dos veces con el mismo DDL (8083 y 8139); el bloque intermedio dice en comentario `BACTH_HOMG_3` pero opera sobre `BACTH_CAMPOS_2`. La primera creación es trabajo desperdiciado.
- `TRANSPUESTA` / `Completitud_Canal`: varias referencias hardcodeadas a `rec_stage` en minúscula, ignorando `P_BDSTAGE`.

#### Techo de avance estimado para F2-4

Migrando `TRANSPUESTA` y `Completitud_Canal` (y el esqueleto de los otros dos), F2-4 pasaría de **12 % a ~45-50 %**. El resto queda contra los insumos del punto A de la lista del 14-oct: filas de `PRO_BATCH2_FILTROS_ESTADISTICAS` (insumo #2) y filas `CANT_REP_CANAL_CONTACTO` de `BATCH_MOTOR_LOG` (insumo #1).

**No se modificó código en esta revisión.** Quedan dos decisiones pendientes del usuario antes de implementar: (1) si en `Completitud_Canal` se replica el bug del loop muerto de DIRECCION o se corrige; (2) si se migra `v_ba2_Campos_Salida` como vista real ahora, cerrando de paso el gap de layout de `exportplano`.

### Prompt (usuario)
> No corrijas ningún bug; la primera fase del proyecto es migrar a Redshift y obtener exactamente los mismos resultados, así sean erróneos; pero crea un archivo md llamado Bugs_Encontrados para documentarlos y, posteriormente en otra fase, sugerir la corrección de los mismos. Continúa con la ejecución de la tarea F2-4 migrando lo que se puede, y no olvides documentar todo en la bitácora

### Respuesta (Kiro) — F2-4 cerrada: los 4 SPs restantes migrados

**Criterio fijado para toda la fase 1:** replicar el comportamiento del original, incluso cuando es incorrecto. Ningún bug se corrige; todos quedan inventariados aparte.

#### Documento nuevo: `Bugs_Encontrados.md` (raíz del workspace)

Inventario de **31 defectos** del código Teradata original (B-01 a B-31), con: objeto afectado, severidad (Alta/Media/Baja), descripción con número de línea del fuente, impacto en la salida, y el archivo Redshift donde se replica cada uno. Incluye los que ya estaban dispersos en esta bitácora (filtros E/F/G/H/J, UDF en C, filas del motor de log) más los 7 nuevos de F2-4.

Declara también las **4 desviaciones deliberadas**, donde replicar era imposible o impedía desplegar:

| ID | Por qué no se replica |
|---|---|
| B-20 | `DataMasking` con ≤3 caracteres devuelve un buffer sin inicializar: no hay resultado determinista que imitar |
| B-21 | `sprintf(salida, cadena)` con el dato como cadena de formato: comportamiento indefinido |
| B-31 | `DROP TABLE` sin `IF EXISTS` en el motor del plan haría fallar la primera corrida en un clúster limpio |
| B-19 / B-30 | Dependen de que el nombre de esquema sea parametrizable; en Redshift es fijo, no se pueden manifestar |

#### Archivos creados

| Archivo | Contenido |
|---|---|
| `Bugs_Encontrados.md` | Inventario de los 31 bugs del original |
| `Redshift/ddl/10_tablas_trabajo_f2_4.sql` | `w_borrar_002` y `w_ejecutor` (DDL de `P0033_BATCH2_CANALCONTACTO_111.BTQ`), más el inventario comentado de las dependencias que F2-4 necesita y la migración aún no construye |
| `Redshift/procedures/09_sp_batch2_otros.sql` | Los 4 SPs restantes de F2-4 + `sp_batch2_estadisticas_export` |

#### Archivos eliminados

- `Redshift/procedures/09_sp_batch2_otros_placeholder.sql`. Con él desaparece el helper `sp_batch2_filtro_placeholder`: **ya no queda ningún placeholder en la migración.**

#### Los 4 SPs migrados

| SP Teradata | Líneas origen | Procedure Redshift | Notas |
|---|---|---|---|
| `PRO_BATCH2_TRANSPUESTA` | 7797–8331 | `sp_batch2_transpuesta(p_lote, p_nombre_proceso, p_batch2_pnpj)` | Genera por cada fila del archivo un `CREATE TABLE bacth_campos_temp` que la pivota a una columna `C<id>`, y vuelca el resultado a `tb_vstg_batch2_*` en formato vertical |
| `PRO_Batch2_Completitud_Canal` | 8332–8958 | `sp_batch2_completitud_canal(p_lote, p_nombre_proceso, p_id_plantilla, p_id_solicitud)` | Arma dinámicamente `tabla_w1`/`tabla_w2` y el `INSERT` que detecta personas con algún campo del canal vacío. Incluye el preámbulo que en Teradata hacía el BTQ |
| `PRO_BATCH2_ESTADISTICAS` | 6161–7796 | `sp_batch2_estadisticas(p_lote, p_nombre_proceso, p_start_timestamp, p_id_plantilla, p_id_solicitud)` | ~25 bloques de SQL inline + 16 delegaciones a `sp_batch2_estadisticas_cfg`. Deja creada la vista `vstg_batch_estadisticas_exp` (las 15 PARTE del archivo de alertas) |
| `PRO_BATCH2_CANTREPCANAL_CON` | 8959–9229 | `sp_batch2_cantrepcanal_con(p_lote, p_nombre_proceso, p_start_timestamp, p_id_solicitud, p_id_plantilla, p_cdatos_sdatos)` | 2 tablas de trabajo + motor sobre `batch_motor_log` con `TIPO='CANT_REP_CANAL_CONTACTO'` |

El orquestador (`10_sp_batch2_proceso_batch2.sql`) ya los invoca en los pasos 8 a 11, con el log de inicio/resultado de cada paso. El paso 8 replica la bifurcación del BTQ: si `archivos_pn_pj = 1` llama a TRANSPUESTA con `vstg_batch2_pn` y luego `vstg_batch2_pj`; si no, una sola vez con `vstg_batch2_pnpj`.

#### Bugs nuevos encontrados en estos 4 SPs (replicados, no corregidos)

- **B-04** `Completitud_Canal`: el bloque de DIRECCIÓN nunca se ejecuta. La condición original `WHILE (V_ITERA <= V_INDICE)` está comentada en el fuente y reemplazada por una fija: el bloque de teléfono quedó en `WHILE (V_ITERA = 1)` con `V_ITERA = 1` (una iteración) y el de dirección en `WHILE (V_ITERA = 2)` con `V_ITERA = 1` (**cero** iteraciones, líneas 8799–8945). `tabla_w2` queda creada y vacía, y del teléfono solo se evalúa la serie 1.
- **B-05** `ESTADISTICAS`: producto cartesiano en el conteo `ID_NE` (el `INNER JOIN` contra el catálogo no tiene predicado de unión) y, además, ese bloque acumula en vez de asignar.
- **B-08** `CANTREPCANAL_CON`: el BTQ pasa `${varPLANTILLA}` al parámetro `P_ID_SOLICITUD` y `${varSOLICITUD}` al `P_ID_PLANTILLA`. El cruce se replica **en el orquestador**, no dentro del procedure, para que el procedure respete su propia firma igual que el SP Teradata.
- **B-10** `ESTADISTICAS`: en la vista del archivo de alertas, `PARTE_11` y `PARTE_12` leen las dos `CIUDAD_DIR_TOTAL`; por simetría `PARTE_12` debería leer `CIUDAD_TEL_TOTAL`. La sección de teléfonos nunca se entrega.
- **B-25** `TRANSPUESTA`: si una partición tiene una sola fila (`MIN_ID = MAX_ID`), gana el `WHEN` del prefijo y el sufijo de cierre nunca se agrega → sentencia sin cerrar.
- **B-26** `ESTADISTICAS`: `BATCH2_ESTADISTICAS_TMP` se borra y nunca se crea (código muerto).
- **B-27** `TRANSPUESTA`: `BACTH_CAMPOS_2` se crea dos veces con el mismo DDL; el bloque intermedio dice `BACTH_HOMG_3` en el comentario pero opera sobre `BACTH_CAMPOS_2`.
- **B-28** `ESTADISTICAS`: descripciones de paso copiadas (`'Crea Tabla BATCH2_ESTADISTICAS_TMP'` se usa al crear `vstg_INCONSIS_PNPJ_TABLA` y `BATCH_CUBO_PERSONA_UNICO`). El log miente; se replica porque el log es parte de la salida comparable.

#### Decisiones de traducción nuevas (en la cabecera del archivo)

- `XMLAGG(x ORDER BY y)` → `LISTAGG(x, ' ') WITHIN GROUP (ORDER BY y)` — **con espacio**, ver el hallazgo de verificación abajo.
- `SELECT TOP n` → `LIMIT n` al final de la sentencia ensamblada.
- `INSERT INTO t (v1, v2, ...)` (forma posicional de Teradata) → `INSERT INTO t VALUES (...)`; en Redshift ese paréntesis sería una lista de columnas.
- `HAVING <alias del SELECT>` → `HAVING <expresión>`; `CASE` que referencia un alias del mismo `SELECT` → subconsulta anidada.
- `COLLECT STATISTICS COLUMN (c) ON t` → `ANALYZE t (c)`.
- `REGEXP_REPLACE(s, p, r, 1, 0, 'i')` → `REGEXP_REPLACE(s, p, r, 1, 'i')` (Redshift reemplaza todas las ocurrencias por defecto y no tiene parámetro de ocurrencia).
- `SUM(1) OVER (ROWS UNBOUNDED PRECEDING)` **sin `ORDER BY`**: Teradata lo permite y devuelve un correlativo en orden físico, que no está definido. Redshift exige `ORDER BY` para usar un marco. Se reemplaza por `ROW_NUMBER() OVER (ORDER BY <llave>)` eligiendo la llave que hace válido el SQL generado (`id, columnid` en TRANSPUESTA, porque `AUTO_ID` tiene que coincidir con `ID_C` dentro de cada partición). **Desviación declarada:** el original es no determinista aquí; la versión Redshift fija un orden.
- Comillas anidadas de 3 niveles: se usa `CHR(39)` en vez de apilar comillas, para que el armado sea auditable. En el fragmento 5 de `Completitud_Canal` el volcado CSV de `Sps_Batch.sql` no permite reconstruir el conteo exacto de comillas del original; se implementó el texto objetivo, que es inequívoco por la versión comentada anterior y porque la sentencia ensamblada debe ser SQL válido.
- `p_batch2_pnpj` se valida contra los 3 valores que el BTQ puede pasar antes de interpolarlo en SQL dinámico. Para esos 3 valores el comportamiento es idéntico al original.

#### Verificación (local, sin clúster)

Dos scripts temporales, ejecutados y después eliminados:

1. **Estructura**: `$$` balanceados y un par por `CREATE PROCEDURE`, comillas pareadas, paréntesis balanceados fuera de literales, sin caracteres no ASCII, cada procedure cerrado con `$$;`. Además se comprobó que **los 33 nombres invocados con `CALL` en todo `procedures/` resuelven** a uno de los 34 `CREATE PROCEDURE` definidos (el único no invocado es el punto de entrada `sp_batch2_proceso_batch2`).
2. **Parseo con `sqlglot` 30.23.0, dialecto Redshift, en los dos niveles** de SQL que estos SP producen:
   - nivel 1: las **67** sentencias que los procedures envían a Redshift, reconstruidas evaluando las concatenaciones `v_sql := ...` con valores de ejemplo;
   - nivel 2: las **5** sentencias que el nivel 1 genera a su vez (el `CREATE TABLE bacth_campos_temp` y el `INSERT` vertical de TRANSPUESTA, el `CREATE TABLE tabla_w1` y el `INSERT` ensamblado de Completitud_Canal, y el cuerpo del `UNLOAD` de alertas).

   Las 72 parsean.

**Dos defectos propios que esta verificación encontró y se corrigieron:**

1. Un literal sin cerrar al armar `sql_1` en `sp_batch2_transpuesta` (desbalance de una comilla en el anidamiento de 3 niveles). Reescrito con `CHR(39)`.
2. **El separador de `XMLAGG` es un espacio, y el código original depende de eso.** La primera versión tradujo `XMLAGG` como `LISTAGG(x, '')`. El parseo de nivel 2 lo detectó: el SQL generado salía con `THEN T.tipo_idWHEN T.id=7...` y `A.CIUDAD_TEL_001FROM rec_stage...`, fragmentos pegados sin separador. En dos lugares independientes el original cuenta con que `XMLAGG` intercale un espacio. Confirmado de forma independiente en `P0033_BATCH2_EXPORTPLANO_120.BTQ` línea 141, donde el propio original hace `OREPLACE(XMLAGG(...), ' ', '')` para **quitar** esos espacios cuando no los quiere. Corregido a `LISTAGG(x, ' ')` en las 5 apariciones; coincide con lo ya concluido el 14-oct en `datos/01_catalogos_motor.sql`. Sin este hallazgo, TRANSPUESTA y Completitud_Canal habrían fallado en ejecución generando SQL inválido.

**No verificado:** ejecución en Redshift; `ANALYZE` dentro de un stored procedure; `QUALIFY` en cada rama de la vista `vstg_batch_estadisticas_exp`; `CREATE OR REPLACE VIEW` cuando cambia el número de columnas; y el resultado funcional frente a Teradata.

#### Hallazgo de alcance: objetos que la migración todavía no construye

`sp_batch2_transpuesta` y `sp_batch2_completitud_canal` leen `rec_stage.v_ba2_campos_salida` y `rec_stage.vstg_batch2_pn/_pj/_pnpj`; `sp_batch2_estadisticas` lee `rec_stage.vstg_inconsis_pnpj`. **Ninguno existe en `Redshift/`**: se verificó que no hay un solo `CREATE VIEW` ni `CREATE TABLE` en `03_sp_batch2_cubo_export.sql` ni en `04_sp_batch2_exportplano.sql`. En Teradata los crean los pasos BTEQ (`CUBOEXPORT_111.BTQ` líneas 43, 177, 1134, 1225 y 1339; `EXPORTPLANO_111/120.BTQ`), mientras el `exportplano` de Redshift va directo de las tablas pivote al `UNLOAD` con un `SELECT` fijo.

Es el mismo vacío de layout ya documentado para Esencial, visto desde otro ángulo: construir `v_ba2_campos_salida` resuelve a la vez el layout dinámico de `exportplano` y esta dependencia. Se incorporó como sección 3.5 de `GUIA_PRUEBA_PRODUCTO_ESENCIAL.md` y como inventario comentado en `ddl/10_tablas_trabajo_f2_4.sql`. **Por eso F2-5 baja de 85 % a 70 %: su alcance creció, no se deshizo trabajo.**

#### Documentación actualizada

- `Redshift/README.md`: sección de placeholders reemplazada por la tabla de F2-4 completada; orden de despliegue con `ddl/10` y con `09b` **antes** de `09` (`sp_batch2_estadisticas` llama a `sp_batch2_estadisticas_cfg`); sección nueva remitiendo a `Bugs_Encontrados.md`.
- `Redshift/VERIFICACION.md`: bloque nuevo con la verificación del 15-oct y los dos defectos propios encontrados.
- `Redshift/GUIA_PRUEBA_PRODUCTO_ESENCIAL.md`: tabla de estado de componentes actualizada, orden de despliegue corregido, sección 3.5 nueva.

#### Avance global estimado: ~85 % (69 % al cierre del 14-oct)

| Bloque | Peso | Avance | Aporte |
|---|---|---|---|
| Análisis y diseño | 10 % | 100 % | 10,0 % |
| DDL | 10 % | 100 % | 10,0 % |
| Helpers + pipeline de exportación CSV | 10 % | 80 % | 8,0 % |
| F2-3 PROCESACUBOS | 30 % | 97 % | 29,1 % |
| F2-4 estadísticas / canal / transpuesta / log / plan | 20 % | 90 % | 18,0 % |
| Orquestador | 5 % | 95 % | 4,75 % |
| Documentación | 5 % | 80 % | 4,0 % |
| Pruebas y validación | 10 % | 12 % | 1,2 % |
| **Total** | **100 %** | | **≈ 85 %** |

"Helpers + pipeline de exportación CSV" baja de 95 % a 80 % por el hallazgo de alcance: `exportplano` debe materializar `v_ba2_campos_salida` y las vistas `vstg_batch2_*`.

#### Qué sigue

| Prioridad | Tarea | Depende de |
|---|---|---|
| 1 | F2-5: construir `v_ba2_campos_salida` (cadena de 3 vistas) y `vstg_batch2_pn/_pj/_pnpj`, y pasar `exportplano` a layout dinámico desde `batch_salidas_campos` | Nada: las definiciones están en los `.BTQ` del workspace |
| 2 | Cargar las filas de `pro_batch2_filtros_estadisticas` y las `CANT_REP_CANAL_CONTACTO` de `batch_motor_log` | Insumos #1 y #2 del equipo Teradata |
| 3 | DDL de `batch_cubo_persona11` y vistas `vu_persona` / `v_tipo_persona` | Insumos #4 y nuevo |
| 4 | Desplegar en el clúster, correr E2E y comparar los CSV con `Salidas/` | Acceso al clúster, bucket S3, IAM Role, Lambda |
| 5 | Fase 2: revisar `Bugs_Encontrados.md` con negocio y decidir qué corregir | Cierre de la fase 1 |

**La lista de insumos pendientes del 14-oct sigue vigente**, con dos adiciones: el DDL de `REC_STAGE.BATCH_Cubo_Persona11` (no aparece en ningún archivo del workspace; lo necesita `CANTREPCANAL_CON`) y la confirmación de si `XMLAGG` en la versión de Teradata en uso separa con un espacio (dado por confirmado a partir del `OREPLACE` de `EXPORTPLANO_120.BTQ`, pero conviene validarlo en el clúster Teradata).
